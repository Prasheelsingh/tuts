﻿using SnapsLibrary;

class Ch09_10_DrawADot
{
    public void StartProgram()
    {
        SnapsEngine.DrawDot(x:100, y:200, width:10);
    }
}
