﻿using SnapsLibrary;

class Ch09_20_PickImage
{
    public void StartProgram()
    {
        SnapsEngine.PickImage();
    }
}