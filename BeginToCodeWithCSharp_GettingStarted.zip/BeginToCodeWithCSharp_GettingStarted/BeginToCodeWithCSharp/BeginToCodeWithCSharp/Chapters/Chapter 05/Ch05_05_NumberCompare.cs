﻿using SnapsLibrary;

class Ch05_05_NumberCompare
{
    public void StartProgram()
    {
        double calculatedPoint3 = (0.1 + 0.2);
        if (calculatedPoint3 == 0.3)
            SnapsEngine.DisplayString("Calculation works");
    }
}