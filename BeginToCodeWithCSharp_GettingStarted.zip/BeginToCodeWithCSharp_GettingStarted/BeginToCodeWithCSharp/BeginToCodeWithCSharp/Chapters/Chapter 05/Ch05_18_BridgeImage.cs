﻿using SnapsLibrary;

class Ch05_18_BridgeImage
{
    public void StartProgram()
    {
        string url = "https://farm9.staticflickr.com/8713/16988005732_7fefe368cc_d.jpg";
        SnapsEngine.DisplayImageFromUrl(imageURL:url);
    }
}

