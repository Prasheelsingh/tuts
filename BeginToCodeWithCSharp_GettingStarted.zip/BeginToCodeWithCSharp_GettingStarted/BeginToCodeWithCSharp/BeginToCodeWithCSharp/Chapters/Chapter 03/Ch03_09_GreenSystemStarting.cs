﻿using SnapsLibrary;

class Ch03_09_GreenSystemStarting
{
    public void StartProgram()
    {
        SnapsEngine.SetTitleColor(SnapsColor.Green);
        SnapsEngine.SetTitleString("System Starting");
    }
}
