﻿using SnapsLibrary;

class Ch03_11_LilacScreen
{
    public void StartProgram()
    {
        SnapsEngine.SetBackgroundColor(red:200,green:162,blue:200);
    }
}