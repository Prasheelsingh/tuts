﻿using SnapsLibrary;

class Ch03_07_BlueText
{
    public void StartProgram()
    {
        SnapsEngine.SetTextColor(SnapsColor.Blue);
        SnapsEngine.DisplayString("Blue Monday");
    }
}