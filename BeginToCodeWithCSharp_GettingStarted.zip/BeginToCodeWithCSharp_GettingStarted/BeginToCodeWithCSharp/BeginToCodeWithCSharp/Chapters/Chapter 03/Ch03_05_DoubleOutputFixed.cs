﻿using SnapsLibrary;

class Ch03_05_DoubleOutputFixed
{
    public void StartProgram()
    {
        SnapsEngine.DisplayString("Computer Running");
        SnapsEngine.SpeakString("Computer Running");
    }
}