﻿using SnapsLibrary;

class Ch03_04_DoubleOutput
{
    public void StartProgram()
    {
        SnapsEngine.SpeakString("Computer Running");
        SnapsEngine.DisplayString("Computer Running");
    }
}