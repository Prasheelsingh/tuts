﻿using SnapsLibrary;

class Ch03_03_Speaking
{
    public void StartProgram()
    {
        SnapsEngine.SpeakString("Hi there. I'm your friendly computer.");
    }
}
