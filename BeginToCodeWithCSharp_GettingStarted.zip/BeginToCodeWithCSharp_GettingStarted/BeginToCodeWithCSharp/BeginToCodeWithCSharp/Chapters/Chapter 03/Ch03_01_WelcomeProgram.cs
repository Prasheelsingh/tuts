﻿using SnapsLibrary;

public class Ch03_01_WelcomeProgram
{
    public void StartProgram()
    {
        SnapsEngine.SetTitleString("Begin to Code with C#");
        SnapsEngine.DisplayString("Welcome to the world of Snaps");
    }
}

