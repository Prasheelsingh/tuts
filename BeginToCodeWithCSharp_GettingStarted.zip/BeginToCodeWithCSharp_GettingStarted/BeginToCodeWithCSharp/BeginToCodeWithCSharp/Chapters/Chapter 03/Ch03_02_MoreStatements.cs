﻿using SnapsLibrary;

class Ch03_02_MoreStatements
{
    public void StartProgram()
    {
        SnapsEngine.DisplayString("Hello world");
        SnapsEngine.DisplayString("Goodbye chickens");
    }
}
