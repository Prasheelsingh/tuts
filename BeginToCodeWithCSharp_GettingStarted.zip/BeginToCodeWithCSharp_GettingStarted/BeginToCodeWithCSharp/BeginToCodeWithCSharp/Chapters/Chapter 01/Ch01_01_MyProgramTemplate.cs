﻿using SnapsLibrary;

class Ch01_01_MyProgramTemplate
{
    public void StartProgram()
    {
        SnapsEngine.SetTitleString("Begin to Code with C#");
        SnapsEngine.DisplayString("Welcome to the world of Snaps");
    }
}
