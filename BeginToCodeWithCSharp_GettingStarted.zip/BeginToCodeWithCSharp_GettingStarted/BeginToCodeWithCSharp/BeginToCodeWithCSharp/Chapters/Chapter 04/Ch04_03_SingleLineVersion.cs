﻿using SnapsLibrary;

class Ch04_03_SingleLineVersion
{
    public void StartProgram()
    {
        SnapsEngine.DisplayString(SnapsEngine.ReadString("What is your name"));
    }
}