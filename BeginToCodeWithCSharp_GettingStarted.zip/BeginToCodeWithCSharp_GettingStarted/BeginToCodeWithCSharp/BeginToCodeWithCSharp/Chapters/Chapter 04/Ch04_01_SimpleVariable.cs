﻿using SnapsLibrary;

class Ch04_01_SimpleVariable
{
    public void StartProgram()
    {
        string guestName;
        guestName = "Rob";
        SnapsEngine.DisplayString(guestName);
    }
}