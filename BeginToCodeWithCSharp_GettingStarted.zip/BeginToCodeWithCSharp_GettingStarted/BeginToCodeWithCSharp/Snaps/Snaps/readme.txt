edit snaps.nuspec to update version and support url

nuget pack Snaps.csproj -IncludeReferencedProjects


nuget setApiKey 6c815a33-c639-4e5c-aa9c-a5c2c130c6d2


                       version
                          |
                          v 
nuget push SnapsLibrary.0.8.nupkg


