﻿namespace SnapsLibrary
{
    public enum SnapsTextAlignment
    {
        left,
        right,
        centre,
        justify
    }
}
