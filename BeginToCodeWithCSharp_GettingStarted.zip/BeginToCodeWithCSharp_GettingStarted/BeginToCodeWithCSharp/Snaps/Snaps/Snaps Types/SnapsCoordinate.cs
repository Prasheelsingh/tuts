﻿
namespace SnapsLibrary
{
    public struct SnapsCoordinate
    {
        public int XValue;
        public int YValue;

        public SnapsCoordinate(int x, int y)
        {
            XValue = x;
            YValue = y;
        }
    }
}
