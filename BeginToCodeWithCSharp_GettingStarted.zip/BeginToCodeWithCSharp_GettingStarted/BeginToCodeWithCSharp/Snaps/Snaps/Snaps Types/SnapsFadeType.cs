﻿namespace SnapsLibrary
{
    public enum SnapsFadeType
    {
        slow,
        fast,
        nofade
    }
}
